const help = (prefix) => {
	return `

╔═══════════════════
║           🌹P4TO 𝐁𝐎𝐓🌹                
╠═══════════════════


➸ Prefix:  *「${prefix} 」*
➸ Status: *「 Online 」*

       • ──── ✾ ──── •
       *FIGURINHAS*【✔】
       • ──── ✾ ──── •
      
➸ Comando : *${prefix}sticker* ou *${prefix}stiker*
➸ Comando : *${prefix}sticker nobg* ou *${prefix}stiker nobg*
➸ útil em : converter imagem em adesivo removendo o fundo
➸ Comando : *${prefix}toimg*
➸ útil em : converter adesivo em imagem
➸ Comando : *${prefix}tsticker* ou *${prefix}tstiker*
➸ útil em : converter texto em adesivo

       • ─── ✾ ─── •
       *MEMES*【✔】
       • ─── ✾ ─── •
      
➸ Comando : *${prefix}meme*
➸ Comando : *${prefix}memeindo*

       • ──── ✾ ──── •
       *OUTROS...*【✔】
       • ──── ✾ ──── •
      
➸ Comando : *${prefix}gtts*
➸ útil em : converter texto em fala/áudio
➸ Comando : *${prefix}loli*
➸ Comando : *${prefix}nsfwloli*
➸ Comando : *${prefix}url2img*
➸ útil em : tirar screenshots da web
➸ Comando : *${prefix}simi*
➸ Comando : *${prefix}ocr*
➸ útil em : pegar o texto da foto e lhe enviar
➸ Comando : *${prefix}wait*
➸ útil em : pesquisar sobre o anime por imagem [ Que anime é este ]
➸ Comando : *${prefix}setprefix*
➸ útil em : alterar o prefixo do bot
➸ Nota : Usado somente pelo proprietário do bot\n

       • ─── ✾ ─── •
       *GRUPO*【✔】
       • ─── ✾ ─── •
      
➸ Comando : *${prefix}linkgroup*
➸ Comando : *${prefix}marcar*
➸ Comando : *${prefix}simih*
➸ útil em : ativar o modo simi no grupo
➸ uso : *${prefix}simih 1* para ativar o modo simi e *${prefix}simih 0* para desativar o modo simih
➸ Comando : *${prefix}add*
➸ Comando : *${prefix}kick*
➸ útil em : remover membros do grupo
➸ Comando : *${prefix}promote*
➸ útil em : tornar membro do grupo um administrador
➸ uso : *${prefix}promote e o @da pessoa*\n
➸ Comando : *${prefix}demote*
➸ útil em : tornar o administrador um membro comum
➸ uso : *${prefix}demote e o @da pessoa*\n

       • ────── ✾ ────── •
       *MENU DO DARK*【✔】
       • ────── ✾ ────── •              

➸ *${prefix}help1* ♔
    

╔════════════════════
  FEITO POR *Patinhas*
  DUVIDAS? 👇
  WA.me/5511934660977
╚════════════════════`
}

exports.help = help






